"obliqueRF" <-
function(x, ...)
  UseMethod("obliqueRF")
