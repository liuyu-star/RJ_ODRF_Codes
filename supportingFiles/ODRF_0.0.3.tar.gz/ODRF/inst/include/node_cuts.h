void gini_split(double , int , int , double* , double* , int , int , int* , double*, double* );
void gini_split(double , int , int , double* , double* , double* , int , int , int* , double*, double* );

void infogain_split(double , int , int , double* , double* , int , int , int* , double*, double* );
void infogain_split(double , int , int , double* , double* , double* , int , int , int* , double*, double* );

void mse_split(double , int , int , double* , double* , int , int* , double*, double* );
void mse_split(double , int , int , double* , double* , double* , int , int* , double*, double* );
