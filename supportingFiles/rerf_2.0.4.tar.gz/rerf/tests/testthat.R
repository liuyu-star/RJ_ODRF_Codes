library(testthat)
library(rerf)

test_check("rerf")
